# -*- coding: utf-8 -*-
# Module: default
# Author: Roman V. M.
# Created on: 28.11.2014
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html

import sys
from urllib import urlencode
from urlparse import parse_qsl
import xbmcgui
import xbmcplugin
import rasp
import xbmc

b = 0
while True:
	xbmc.sleep(5000)

	a = rasp.main()
	if a != False:

		if xbmc.Player().isPlayingAudio() == True:
			xbmc.Player().stop()
			xbmc.sleep(1000)
			xbmc.Player().play(a)
			xbmc.sleep(10000)
		else:

			xbmc.Player().play(a)
			xbmc.sleep(10000)





