import requests
def main():
        try:
                a =  requests.get("http://192.168.1.220/top", timeout=10).text
                b = str(a)
                if len(b) > 5:
                        if "http" in b:
                                url =  b.replace(" ", "%20")
                        else:
                                url = b.replace(" ", "%20")
                        return url
                else:
                        return False
        except:
                pass

